extends CharacterBody2D

# Cena independente de demonstracao da animacao de salto e poeira.
# NAO substitua o player_microastro.gd existente automaticamente.
@export var velocidade: float = 120.0
@export var aceleracao: float = 900.0
@export var frenagem: float = 1100.0
@export var impulso_salto: float = 155.0
@export var gravidade_salto: float = 310.0

@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D
@onready var poeira: AnimatedSprite2D = $Poeira

var ultima_direcao: String = "frente"
var altura: float = 0.0
var velocidade_vertical: float = 0.0
var pulando: bool = false
var posicao_original_sprite: Vector2 = Vector2.ZERO

func _ready() -> void:
    posicao_original_sprite = sprite.position
    poeira.visible = false
    poeira.animation_finished.connect(_esconder_poeira)

func _physics_process(delta: float) -> void:
    var direcao: Vector2 = Input.get_vector(
        "ui_left", "ui_right", "ui_up", "ui_down"
    )

    if direcao != Vector2.ZERO:
        velocity = velocity.move_toward(direcao * velocidade, aceleracao * delta)
        if abs(direcao.x) > abs(direcao.y):
            ultima_direcao = "direita" if direcao.x > 0 else "esquerda"
        else:
            ultima_direcao = "frente" if direcao.y > 0 else "tras"
    else:
        velocity = velocity.move_toward(Vector2.ZERO, frenagem * delta)
    move_and_slide()

    # Simulacao visual: a posicao real/collision permanece no solo.
    if Input.is_action_just_pressed("pular") and not pulando:
        pulando = true
        velocidade_vertical = -impulso_salto
        _soltar_poeira()

    if pulando:
        velocidade_vertical += gravidade_salto * delta
        altura += velocidade_vertical * delta
        if altura >= 0.0:
            altura = 0.0
            velocidade_vertical = 0.0
            pulando = false
            _soltar_poeira()

    sprite.position = posicao_original_sprite + Vector2(0.0, altura)
    queue_redraw()

    if pulando:
        var animacao: String = "pular_" + ultima_direcao
        # Nao recomecar a animacao nao-loop no ultimo quadro.
        if sprite.animation != animacao:
            sprite.play(animacao)
    else:
        var animacao: String
        if direcao != Vector2.ZERO:
            animacao = "andar_" + ultima_direcao
        else:
            animacao = "parado_" + ultima_direcao
        if sprite.animation != animacao or not sprite.is_playing():
            sprite.play(animacao)

func _soltar_poeira() -> void:
    poeira.visible = true
    poeira.stop()
    poeira.frame = 0
    poeira.play("poeira")

func _esconder_poeira() -> void:
    poeira.visible = false

func _draw() -> void:
    var opacidade: float = clampf(0.40 + altura * 0.006, 0.15, 0.40)
    draw_set_transform(Vector2(0.0, 22.0), 0.0, Vector2(1.0, 0.4))
    draw_circle(Vector2.ZERO, 12.0, Color(0.0, 0.0, 0.0, opacidade))

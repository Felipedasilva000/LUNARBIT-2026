extends Node2D

func _draw() -> void:
    draw_rect(Rect2(0, 0, 320, 180), Color(0.14, 0.19, 0.27))
    for x in range(0, 321, 16):
        draw_line(Vector2(x, 0), Vector2(x, 180), Color(0.30, 0.35, 0.42, 0.45), 1.0)
    for y in range(0, 181, 16):
        draw_line(Vector2(0, y), Vector2(320, y), Color(0.30, 0.35, 0.42, 0.45), 1.0)

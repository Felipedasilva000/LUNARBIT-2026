extends Node2D

@export var velocidade: float = 95.0

func _process(delta: float) -> void:
    var movimento: Vector2 = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
    position += movimento * velocidade * delta
    position = position.clamp(Vector2(12, 12), Vector2(308, 168))

func _draw() -> void:
    draw_circle(Vector2(0, 0), 8.0, Color(0.9, 0.94, 0.98))
    draw_circle(Vector2(0, -2), 5.0, Color(0.08, 0.31, 0.48))
    draw_rect(Rect2(-4, 5, 8, 3), Color(1.0, 0.62, 0.15))

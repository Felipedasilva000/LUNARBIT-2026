extends CanvasLayer
class_name HUDAstronautico

# Interface independente: NAO altera o astronauta, a camera ou as missoes.
# Valores: 0 = vazio; 100 = cheio.
@export_group("Valores iniciais")
@export_range(0.0, 100.0, 0.1) var sede: float = 100.0
@export_range(0.0, 100.0, 0.1) var fome: float = 100.0
@export_range(0.0, 100.0, 0.1) var sanidade: float = 100.0

@export_group("Consumo com o tempo")
@export var consumo_ativo: bool = true
@export_range(0.0, 60.0, 0.1, "or_greater") var sede_por_minuto: float = 12.0
@export_range(0.0, 60.0, 0.1, "or_greater") var fome_por_minuto: float = 7.0
@export_range(0.0, 60.0, 0.1, "or_greater") var sanidade_por_minuto: float = 4.0
@export_range(0.1, 20.0, 0.1, "or_greater") var velocidade_tempo: float = 1.0

@export_group("Visual")
@export var posicao_hud: Vector2 = Vector2(4, 4)
@export_range(0.05, 1.0, 0.005) var escala_hud: float = 0.105
@export var adaptar_tamanho_da_tela: bool = true
@export var alerta_vermelho_abaixo_de_20: bool = true

signal valores_atualizados(sede_atual: float, fome_atual: float, sanidade_atual: float)

const HUD_TEXTURE: Texture2D = preload("res://HUD_Astronautico/assets/hud_frame.png")
# Retangulos dos preenchimentos, em coordenadas da arte original de 1448x1086.
const REGIOES := {
    "sede": Rect2(470, 410, 782, 33),
    "fome": Rect2(470, 547, 782, 33),
    "sanidade": Rect2(470, 685, 782, 33),
}
const CORES := {
    "sede": Color(0.137255, 0.866667, 0.960784),
    "fome": Color(1.0, 0.666667, 0.2),
    "sanidade": Color(0.698039, 0.466667, 0.964706),
}
const SEGMENTOS: int = 12
const ESPACO_SEGMENTO: float = 8.0

var _painel: Control
var _segmentos: Dictionary = {}

func _ready() -> void:
    _criar_interface()
    _atualizar_visual()
    get_viewport().size_changed.connect(_ajustar_escala)

func _process(delta: float) -> void:
    if not consumo_ativo:
        return
    var minutos: float = maxf(delta, 0.0) / 60.0 * velocidade_tempo
    sede = clampf(sede - sede_por_minuto * minutos, 0.0, 100.0)
    fome = clampf(fome - fome_por_minuto * minutos, 0.0, 100.0)
    sanidade = clampf(sanidade - sanidade_por_minuto * minutos, 0.0, 100.0)
    _atualizar_visual()
    valores_atualizados.emit(sede, fome, sanidade)

func _criar_interface() -> void:
    _painel = Control.new()
    _painel.name = "HUD_Painel"
    _painel.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _painel.position = posicao_hud
    _painel.size = HUD_TEXTURE.get_size()
    add_child(_painel)

    var fundo := TextureRect.new()
    fundo.name = "Moldura_SciFi"
    fundo.texture = HUD_TEXTURE
    fundo.size = HUD_TEXTURE.get_size()
    fundo.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
    fundo.stretch_mode = TextureRect.STRETCH_SCALE
    fundo.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    fundo.mouse_filter = Control.MOUSE_FILTER_IGNORE
    _painel.add_child(fundo)

    for nome in ["sede", "fome", "sanidade"]:
        _criar_segmentos(nome)
    _ajustar_escala()

func _criar_segmentos(nome: String) -> void:
    var regiao: Rect2 = REGIOES[nome]
    var largura: float = (regiao.size.x - ESPACO_SEGMENTO * float(SEGMENTOS - 1)) / float(SEGMENTOS)
    var grupo: Array[ColorRect] = []
    for i in range(SEGMENTOS):
        var barra := ColorRect.new()
        barra.name = "%s_%02d" % [nome, i + 1]
        barra.position = regiao.position + Vector2(float(i) * (largura + ESPACO_SEGMENTO), 0)
        barra.size = Vector2(largura, regiao.size.y)
        barra.color = CORES[nome]
        barra.mouse_filter = Control.MOUSE_FILTER_IGNORE
        _painel.add_child(barra)
        grupo.append(barra)
    _segmentos[nome] = grupo

func _atualizar_visual() -> void:
    _desenhar_barra("sede", sede)
    _desenhar_barra("fome", fome)
    _desenhar_barra("sanidade", sanidade)

func _desenhar_barra(nome: String, valor: float) -> void:
    var restante: float = clampf(valor, 0.0, 100.0) / 100.0 * float(SEGMENTOS)
    var regiao: Rect2 = REGIOES[nome]
    var largura: float = (regiao.size.x - ESPACO_SEGMENTO * float(SEGMENTOS - 1)) / float(SEGMENTOS)
    var cor: Color = CORES[nome]
    if alerta_vermelho_abaixo_de_20 and valor <= 20.0:
        cor = Color(1.0, 0.254902, 0.294118)
    var grupo: Array = _segmentos[nome]
    for i in range(SEGMENTOS):
        var barra: ColorRect = grupo[i]
        var preenchido: float = clampf(restante - float(i), 0.0, 1.0)
        barra.size.x = largura * preenchido
        barra.visible = preenchido > 0.001
        barra.color = cor

func _ajustar_escala() -> void:
    if _painel == null:
        return
    var escala_final: float = escala_hud
    if adaptar_tamanho_da_tela:
        var tela: Vector2 = get_viewport().get_visible_rect().size
        var limite_x: float = (tela.x - posicao_hud.x - 4.0) / HUD_TEXTURE.get_width()
        var limite_y: float = (tela.y - posicao_hud.y - 4.0) / HUD_TEXTURE.get_height()
        escala_final = minf(minf(escala_final, limite_x), limite_y)
    _painel.scale = Vector2.ONE * maxf(0.01, escala_final)

# ===== API PARA FUTURAS MISSOES =====
func set_sede(valor: float) -> void:
    sede = clampf(valor, 0.0, 100.0)
    _atualizar_visual()

func set_fome(valor: float) -> void:
    fome = clampf(valor, 0.0, 100.0)
    _atualizar_visual()

func set_sanidade(valor: float) -> void:
    sanidade = clampf(valor, 0.0, 100.0)
    _atualizar_visual()

func alterar_sede(delta: float) -> void:
    set_sede(sede + delta)

func alterar_fome(delta: float) -> void:
    set_fome(fome + delta)

func alterar_sanidade(delta: float) -> void:
    set_sanidade(sanidade + delta)

func set_status_completo(nova_sede: float, nova_fome: float, nova_sanidade: float) -> void:
    set_sede(nova_sede)
    set_fome(nova_fome)
    set_sanidade(nova_sanidade)

func pausar_consumo() -> void:
    consumo_ativo = false

func retomar_consumo() -> void:
    consumo_ativo = true

func mostrar_hud() -> void:
    visible = true

func esconder_hud() -> void:
    visible = false

func reposicionar_hud(nova_posicao: Vector2) -> void:
    posicao_hud = nova_posicao
    if _painel:
        _painel.position = posicao_hud
        _ajustar_escala()

func redefinir_escala(nova_escala: float) -> void:
    escala_hud = maxf(nova_escala, 0.05)
    _ajustar_escala()

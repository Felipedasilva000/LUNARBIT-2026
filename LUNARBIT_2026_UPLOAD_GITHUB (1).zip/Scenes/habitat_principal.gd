
@tool
extends Node2D

func _draw() -> void:
	# Sombra do habitat
	draw_rect(
		Rect2(-145, -75, 290, 165),
		Color("#414955")
	)

	# Estrutura principal
	draw_rect(
		Rect2(-136, -85, 272, 155),
		Color("#AEBBC7")
	)

	# Cobertura superior
	draw_rect(
		Rect2(-125, -75, 250, 35),
		Color("#66798D")
	)

	# Faixa laranja de identificacao
	draw_rect(
		Rect2(-125, -40, 250, 7),
		Color("#E99A45")
	)

	# Janela esquerda
	draw_rect(
		Rect2(-112, -15, 65, 38),
		Color("#29465F")
	)

	# Janela direita
	draw_rect(
		Rect2(47, -15, 65, 38),
		Color("#29465F")
	)

	# Moldura da entrada
	draw_rect(
		Rect2(-36, 12, 72, 65),
		Color("#D18C42")
	)

	# Porta central da eclusa
	draw_rect(
		Rect2(-26, 21, 52, 56),
		Color("#47586B")
	)

	# Divisao das portas
	draw_line(
		Vector2(0, 21),
		Vector2(0, 77),
		Color("#AABAC8"),
		3.0
	)

	# Degrau de acesso
	draw_rect(
		Rect2(-43, 77, 86, 12),
		Color("#848E9D")
	)

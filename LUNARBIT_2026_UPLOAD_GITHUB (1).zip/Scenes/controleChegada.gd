
extends Node2D

@export var jogador: CharacterBody2D

func _ready() -> void:
	call_deferred("_posicionar_jogador")


func _posicionar_jogador() -> void:
	var raiz := get_tree().root

	if not raiz.has_meta("lunarbit_chegada"):
		return

	var nome := str(raiz.get_meta("lunarbit_chegada"))
	var ponto := get_node_or_null(NodePath(nome))

	if not ponto is Marker2D:
		push_warning("Ponto de chegada não encontrado: " + nome)
		return

	if jogador == null:
		push_warning("Jogador não configurado!")
		return

	jogador.global_position = ponto.global_position
	jogador.velocity = Vector2.ZERO

	raiz.remove_meta("lunarbit_chegada")

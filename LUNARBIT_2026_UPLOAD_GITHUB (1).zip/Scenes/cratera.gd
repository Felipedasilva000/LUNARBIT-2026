
@tool
extends Node2D

func _draw() -> void:
	# Sombra externa da cratera
	draw_circle(
		Vector2(0, 3),
		30,
		Color("#555D68")
	)

	# Borda iluminada
	draw_circle(
		Vector2.ZERO,
		27,
		Color("#A5ADB6")
	)

	# Interior mais escuro
	draw_circle(
		Vector2(0, 3),
		21,
		Color("#626A76")
	)

	# Detalhes internos
	draw_circle(
		Vector2(-5, -4),
		13,
		Color("#777F89")
	)

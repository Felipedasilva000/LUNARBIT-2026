
@tool
extends Node2D

func _draw() -> void:
	# DESENHA QUATRO PAINEIS SOLARES
	for linha in range(2):
		for coluna in range(2):

			var x = -99.0 + coluna * 100.0
			var y = -53.0 + linha * 60.0

			# Suportes metalicos
			draw_rect(
				Rect2(x + 10, y + 45, 8, 15),
				Color("#535C69")
			)

			draw_rect(
				Rect2(x + 70, y + 45, 8, 15),
				Color("#535C69")
			)

			# Moldura externa
			draw_rect(
				Rect2(x, y, 88, 48),
				Color("#303C4C")
			)

			# Celulas solares azuis
			draw_rect(
				Rect2(x + 4, y + 4, 80, 40),
				Color("#295880")
			)

			# Linhas verticais das celulas
			for i in range(1, 4):
				draw_line(
					Vector2(x + 4 + i * 20, y + 4),
					Vector2(x + 4 + i * 20, y + 44),
					Color("#83B9DA"),
					1.0
				)

			# Linha horizontal
			draw_line(
				Vector2(x + 4, y + 24),
				Vector2(x + 84, y + 24),
				Color("#83B9DA"),
				1.0
			)

	# CABO DE ENERGIA
	draw_line(
		Vector2(140, 10),
		Vector2(174, 10),
		Color("#E5A54D"),
		4.0
	)

	# CENTRAL DE CONTROLE
	draw_rect(
		Rect2(101, -5, 38, 31),
		Color("#D2D9E1")
	)

	draw_rect(
		Rect2(107, 1, 26, 17),
		Color("#344A60")
	)

	# Indicador luminoso
	draw_circle(
		Vector2(120, 10),
		4,
		Color("#6EE7A8")
	)

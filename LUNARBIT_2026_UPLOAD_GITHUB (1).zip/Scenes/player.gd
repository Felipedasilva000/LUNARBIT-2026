
extends CharacterBody2D

# Velocidade do astronauta
@export var velocidade: float = 120.0

func _physics_process(_delta: float) -> void:
	# Identifica as setas pressionadas
	var direcao = Input.get_vector(
		"ui_left",
		"ui_right",
		"ui_up",
        "ui_down"
	)

	# Define a velocidade do astronauta
	velocity = direcao * velocidade

	# Executa o movimento
	move_and_slide()

extends Node2D
# Cena independente para a escotilha de 9 quadros (uso opcional).
# Nao e instanciada automaticamente no InteriorAndar1: escolha o encaixe no editor.

@onready var porta: AnimatedSprite2D = $Porta
@onready var area: Area2D = $AreaInteracao

var jogador_proximo := false
var aberta := false


func _ready() -> void:
    porta.play(&"abrir")
    porta.stop()
    porta.frame = 0
    area.body_entered.connect(_entrou)
    area.body_exited.connect(_saiu)
    porta.animation_finished.connect(_fim)


func _entrou(corpo: Node2D) -> void:
    if corpo is CharacterBody2D:
        jogador_proximo = true


func _saiu(corpo: Node2D) -> void:
    if corpo is CharacterBody2D:
        jogador_proximo = false


func _unhandled_input(event: InputEvent) -> void:
    if not jogador_proximo or porta.is_playing():
        return
    if not InputMap.has_action("interagir"):
        return
    if event is InputEventKey and event.echo:
        return
    if event.is_action_pressed("interagir"):
        porta.play(&"fechar" if aberta else &"abrir")
        get_viewport().set_input_as_handled()


func _fim() -> void:
    aberta = (porta.animation == &"abrir")

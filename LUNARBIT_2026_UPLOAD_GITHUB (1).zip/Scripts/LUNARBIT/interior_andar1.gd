extends Node2D

# Ajustes da escotilha superior (coordenadas da arte original).
@export var posicao_escotilha: Vector2 = Vector2(578, 140)
@export_range(0.1, 2.0, 0.05) var escala_escotilha: float = 0.60
# LUNARBIT - Sala interna do primeiro andar.
# Usa a arte original, sem alterar PNGs, e o Microastro que ja existe no projeto.

@export_file("*.tscn") var cena_exterior: String = "res://Scenes/main.tscn"
@onready var mapa: Node2D = $Mapa
@onready var jogador: CharacterBody2D = $Mapa/PlayerMicroastro
@onready var camera_interior: Camera2D = $CameraInterior
@onready var titulo: Label = $HUD/Titulo
@onready var dica: Label = $HUD/Dica
@onready var mensagem: Label = $HUD/Mensagem

# Interacoes do primeiro andar. O segundo andar sera adicionado depois.
const TITULOS = {
    "SaidaExterior": "E - Sair para a superficie",
    "EscadaSuperior": "E - Acessar escada superior",
    "ConsoleCentral": "E - Consultar sistemas da base",
    "SuporteVida": "E - Ver suporte a vida",
    "Laboratorio": "E - Inspecionar laboratorio",
    "Oficina": "E - Usar bancada de manutencao",
    "Trajes": "E - Ver trajes espaciais",
    "Energia": "E - Ver energia e baterias",
    "Armazenamento": "E - Consultar armazenamento"
}

const DESCRICOES = {
    "EscadaSuperior": "SEGUNDO ANDAR\nAinda nao construido. Esta escada sera a ligacao com os proximos modulos.",
    "ConsoleCentral": "CONTROLE DA BASE ALPHA 01\nOxigenio: aguardando sistema\nEnergia: aguardando sistema\nRadiacao: aguardando sistema",
    "SuporteVida": "SUPORTE A VIDA\nReservatorios, filtros e reciclagem de agua.\nOs valores reais serao programados depois.",
    "Laboratorio": "LABORATORIO LUNAR\nAqui analisaremos amostras de regolito e resultados de pesquisa.",
    "Oficina": "OFICINA\nEste sera o ponto de conserto de equipamentos e rover.",
    "Trajes": "EQUIPAMENTOS EVA\nO armario de trajes sera usado antes das atividades externas.",
    "Energia": "ENERGIA DA BASE\nMonitoramento de baterias e consumo sera adicionado depois.",
    "Armazenamento": "ARMAZENAMENTO\nEstoque de suprimentos e pecas de reposicao (futuro)."
}

const ORDEM_PRIORIDADE = [
    "SaidaExterior", "EscadaSuperior", "ConsoleCentral", "SuporteVida",
    "Laboratorio", "Oficina", "Trajes", "Energia", "Armazenamento"
]

var jogador_em_areas: Dictionary = {}
var mensagem_aberta: bool = false
var escotilha_topo: Node2D = null


func _ready() -> void:
    # A camera da cena oficial do Microastro nao deve disputar com esta camera.
    var camera_antiga := jogador.get_node_or_null("Camera2D") as Camera2D
    if camera_antiga != null:
        camera_antiga.enabled = false
    camera_interior.make_current()

    # HUD compacto para nao ocupar a tela nem esconder a arte.
    titulo.add_theme_font_size_override("font_size", 12)
    titulo.text = "BASE ALPHA 01 | ANDAR 1"
    dica.add_theme_font_size_override("font_size", 13)
    mensagem.add_theme_font_size_override("font_size", 14)
    dica.hide()
    mensagem.hide()

    _preparar_escotilha()

    for nome in TITULOS.keys():
        var area := get_node_or_null("Mapa/Interacoes/" + nome) as Area2D
        if area == null:
            push_warning("LUNARBIT: area ausente: " + nome)
            continue
        area.body_entered.connect(_ao_entrar_area.bind(nome))
        area.body_exited.connect(_ao_sair_area.bind(nome))

    if not InputMap.has_action("interagir"):
        push_warning("Configure a acao 'interagir' com a tecla E no Mapa de Entrada.")
    _seguir_jogador()


func _preparar_escotilha() -> void:
    # Cria a camada automaticamente; nao substitui InteriorAndar1.tscn.
    escotilha_topo = mapa.get_node_or_null("EscotilhaTopo") as Node2D
    if escotilha_topo == null:
        var recurso: PackedScene = load("res://ScenesExtras/EscotilhaTopoInterativa.tscn") as PackedScene
        if recurso == null:
            push_warning("Nao foi possivel carregar a escotilha superior.")
            return
        escotilha_topo = recurso.instantiate() as Node2D
        escotilha_topo.name = "EscotilhaTopo"
        mapa.add_child(escotilha_topo)
        escotilha_topo.position = posicao_escotilha
        escotilha_topo.scale = Vector2.ONE * escala_escotilha

    var animacao: AnimatedSprite2D = escotilha_topo.get_node_or_null("Porta") as AnimatedSprite2D
    if animacao != null:
        animacao.animation_finished.connect(_atualizar_dica)


func _process(_delta: float) -> void:
    _seguir_jogador()


func _seguir_jogador() -> void:
    # Mapa escalado; camera fica em coordenadas globais.
    # Preserva o centro horizontal quando o mapa e estreito em relacao a tela.
    var tamanho_mapa := Vector2(1159.0, 1358.0) * mapa.scale
    var centro := jogador.global_position
    var metade_visivel := get_viewport_rect().size / (camera_interior.zoom * 2.0)

    if tamanho_mapa.x <= metade_visivel.x * 2.0:
        centro.x = tamanho_mapa.x / 2.0
    else:
        centro.x = clampf(centro.x, metade_visivel.x, tamanho_mapa.x - metade_visivel.x)
    if tamanho_mapa.y <= metade_visivel.y * 2.0:
        centro.y = tamanho_mapa.y / 2.0
    else:
        centro.y = clampf(centro.y, metade_visivel.y, tamanho_mapa.y - metade_visivel.y)

    camera_interior.global_position = centro


func _ao_entrar_area(corpo: Node2D, nome: String) -> void:
    if corpo == jogador:
        jogador_em_areas[nome] = true
        _atualizar_dica()


func _ao_sair_area(corpo: Node2D, nome: String) -> void:
    if corpo == jogador:
        jogador_em_areas.erase(nome)
        _atualizar_dica()


func _area_prioritaria() -> String:
    for nome in ORDEM_PRIORIDADE:
        if jogador_em_areas.get(nome, false):
            return nome
    return ""


func _atualizar_dica() -> void:
    if mensagem_aberta:
        dica.text = "E - Fechar informacoes"
        dica.show()
        return

    var nome: String = _area_prioritaria()
    dica.visible = not nome.is_empty()
    if nome.is_empty():
        return

    if nome == "EscadaSuperior" and escotilha_topo != null:
        if escotilha_topo.call("esta_animando"):
            dica.hide()
        else:
            dica.text = "E - Fechar escotilha" if escotilha_topo.call("esta_aberta") else "E - Abrir escotilha"
    else:
        dica.text = TITULOS[nome]


func _unhandled_input(event: InputEvent) -> void:
    if not InputMap.has_action("interagir"):
        return
    if event is InputEventKey and event.echo:
        return
    if not event.is_action_pressed("interagir"):
        return

    if mensagem_aberta:
        mensagem_aberta = false
        mensagem.hide()
        _atualizar_dica()
        get_viewport().set_input_as_handled()
        return

    var nome := _area_prioritaria()
    if nome.is_empty():
        return

    if nome == "SaidaExterior":
        # Usa a cena externa que ja existe.
        if ResourceLoader.exists(cena_exterior):
            get_tree().call_deferred("change_scene_to_file", cena_exterior)
        else:
            push_error("Cena externa nao encontrada: " + cena_exterior)
    elif nome == "EscadaSuperior" and escotilha_topo != null:
        escotilha_topo.call("alternar")
        _atualizar_dica()
    else:
        mensagem.text = DESCRICOES.get(nome, "Sistema ainda em desenvolvimento.")
        mensagem.show()
        mensagem_aberta = true
        _atualizar_dica()

    get_viewport().set_input_as_handled()


extends Node2D

# LUNARBIT - Eclusa externa com entrada condicional.

@export var ajuste_porta_entreaberta: Vector2 = Vector2.ZERO
@export var ajuste_porta_aberta: Vector2 = Vector2.ZERO

@onready var porta: AnimatedSprite2D = $Porta
@onready var area_interacao: Area2D = $AreaInteracao
@onready var area_entrada: Area2D = $AreaEntrada
@onready var dica: Label = $Dica

var posicao_base_porta: Vector2 = Vector2.ZERO

var jogador_proximo: bool = false
var jogador_na_entrada: bool = false
var porta_aberta: bool = false
var entrando: bool = false


func _ready() -> void:
	posicao_base_porta = porta.position

	porta.animation = &"abrir"
	porta.stop()
	porta.frame = 0
	dica.hide()

	# Animacao da escotilha.
	porta.frame_changed.connect(_ajustar_porta)
	porta.animation_changed.connect(_ajustar_porta)
	porta.animation_finished.connect(_animacao_finalizada)

	# Area onde o jogador pode abrir a porta.
	area_interacao.body_entered.connect(_ao_entrar)
	area_interacao.body_exited.connect(_ao_sair)

	# Area que permite entrar na estacao.
	area_entrada.body_entered.connect(_entrar_na_entrada)
	area_entrada.body_exited.connect(_sair_da_entrada)

	_ajustar_porta()


# DETECCAO DA AREA DE INTERACAO

func _ao_entrar(corpo: Node2D) -> void:
	if corpo is CharacterBody2D:
		jogador_proximo = true
		_atualizar_dica()


func _ao_sair(corpo: Node2D) -> void:
	if corpo is CharacterBody2D:
		jogador_proximo = false
		_atualizar_dica()


# DETECCAO DA ENTRADA DA ESTACAO

func _entrar_na_entrada(corpo: Node2D) -> void:
	if corpo is CharacterBody2D:
		jogador_na_entrada = true
		_atualizar_dica()


func _sair_da_entrada(corpo: Node2D) -> void:
	if corpo is CharacterBody2D:
		jogador_na_entrada = false
		_atualizar_dica()


# CONTROLE DA TECLA E

func _unhandled_input(event: InputEvent) -> void:
	if porta.is_playing():
		return

	if not InputMap.has_action("interagir"):
		return

	if event is InputEventKey and event.echo:
		return

	if not event.is_action_pressed("interagir"):
		return

	if not porta_aberta:
		# Abre somente se o jogador estiver proximo.
		if not jogador_proximo:
			return

		porta.play(&"abrir")

	else:
		# A porta ja esta aberta.
		if not jogador_proximo and not jogador_na_entrada:
			return

		# So entra se estiver na area correta.
		entrando = jogador_na_entrada

		porta.play(&"fechar")

	dica.hide()
	get_viewport().set_input_as_handled()


# FINAL DA ANIMACAO

func _animacao_finalizada() -> void:
	porta_aberta = (porta.animation == &"abrir")

	_ajustar_porta()
	_atualizar_dica()

	# Duas condicoes necessarias para a entrada:
	# 1. O jogador estava na area da porta.
	# 2. Ele acionou o fechamento da escotilha.
	if entrando and not porta_aberta:
		entrando = false

		get_tree().call_deferred(
			"change_scene_to_file",
			"res://Scenes/InteriorAndar1.tscn"
		)


# MENSAGENS DE INTERACAO

func _atualizar_dica() -> void:
	if porta.is_playing():
		dica.hide()
		return

	if porta_aberta and jogador_na_entrada:
		dica.text = "E - Fechar e entrar"

	elif porta_aberta and jogador_proximo:
		dica.text = "E - Fechar eclusa"

	elif jogador_proximo:
		dica.text = "E - Abrir eclusa"

	else:
		dica.hide()
		return

	dica.show()


# ALINHAMENTO INDIVIDUAL DOS QUADROS

func _ajustar_porta() -> void:
	var quadro_visual: int = porta.frame

	if porta.animation == &"fechar":
		quadro_visual = 2 - quadro_visual

	var ajuste: Vector2 = Vector2.ZERO

	match quadro_visual:
		0:
			ajuste = Vector2.ZERO
		1:
			ajuste = ajuste_porta_entreaberta
		2:
			ajuste = ajuste_porta_aberta

	porta.position = posicao_base_porta + ajuste

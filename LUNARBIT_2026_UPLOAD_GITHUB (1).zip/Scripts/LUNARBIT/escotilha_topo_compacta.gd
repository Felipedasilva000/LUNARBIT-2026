extends Node2D
# Porta superior: animacao independente, sem alterar o cenario.

@onready var porta: AnimatedSprite2D = $Porta
var aberta: bool = false

func _ready() -> void:
    porta.animation = &"abrir"
    porta.stop()
    porta.frame = 0
    porta.animation_finished.connect(_quando_terminar)

func alternar() -> void:
    if porta.is_playing():
        return
    porta.play(&"fechar" if aberta else &"abrir")

func esta_aberta() -> bool:
    return aberta

func esta_animando() -> bool:
    return porta.is_playing()

func _quando_terminar() -> void:
    aberta = porta.animation == &"abrir"

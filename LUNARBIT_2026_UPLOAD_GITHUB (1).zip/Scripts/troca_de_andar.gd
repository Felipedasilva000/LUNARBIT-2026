
extends Area2D

@export_range(0.0, 3.0, 0.1) var tempo_transicao: float = 0.3

var em_transicao: bool = false


# LUNARBIT - Navegacao entre andares

@export_file("*.tscn") var cena_destino: String = ""
@export var id_desta_escada: String = ""
@export var id_escada_destino: String = ""
@export var deslocamento_chegada: Vector2 = Vector2(0, 25)

@onready var jogador: CharacterBody2D = get_parent().get_node_or_null("PlayerMicroastro") as CharacterBody2D
@onready var dica: Label = get_node_or_null("Dica") as Label

var jogador_proximo: bool = false


func _ready() -> void:
	body_entered.connect(_ao_entrar)
	body_exited.connect(_ao_sair)

	if dica:
		dica.hide()

	# Recupera a posicao de chegada ao mudar de andar.
	var chegada: String = str(
		get_tree().root.get_meta("lunarbit_chegada", "")
	)

	if chegada == id_desta_escada and chegada != "":
		if jogador:
			jogador.global_position = global_position + deslocamento_chegada

		get_tree().root.remove_meta("lunarbit_chegada")



func _ao_entrar(corpo: Node2D) -> void:
	print("Algo entrou na escada: ", corpo.name)

	if corpo is CharacterBody2D:
		jogador_proximo = true
		print("Microastro detectado!")

		if dica:
			dica.show()




func _ao_sair(corpo: Node2D) -> void:
	if corpo is CharacterBody2D:
		jogador_proximo = false

		if dica:
			dica.hide()




func _unhandled_input(event: InputEvent) -> void:
	if em_transicao:
		return

	if not jogador_proximo:
		return

	if event is InputEventKey and event.echo:
		return

	if not event.is_action_pressed("interagir"):
		return

	if cena_destino.is_empty():
		return

	em_transicao = true
	get_viewport().set_input_as_handled()

	get_tree().root.set_meta(
		"lunarbit_chegada",
		id_escada_destino
	)

	# Aguarda o tempo configurado.
	await get_tree().create_timer(tempo_transicao).timeout

	# Troca para o proximo andar.
	get_tree().call_deferred(
		"change_scene_to_file",
		cena_destino
	)

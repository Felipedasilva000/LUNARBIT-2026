
extends CharacterBody2D

# CONFIGURACOES DO ASTRONAUTA
@export var velocidade: float = 120.0

# CONTROLE DE ACELERACAO E FRENAGEM
@export var aceleracao: float = 900.0
@export var frenagem: float = 1100.0

# CONFIGURACOES DO SALTO LUNAR
@export var impulso_salto: float = 155.0
@export var gravidade_salto: float = 310.0

# REFERENCIA AO SPRITE
@onready var sprite: AnimatedSprite2D = $AnimatedSprite2D

# CONTROLE DAS ANIMACOES
var ultima_direcao: String = "frente"

# CONTROLE DO SALTO
var altura: float = 0.0
var velocidade_vertical: float = 0.0
var pulando: bool = false
var posicao_original_sprite: Vector2 = Vector2.ZERO


func _ready() -> void:
	# Guarda a posicao original do desenho
	posicao_original_sprite = sprite.position


func _physics_process(delta: float) -> void:

	# MOVIMENTACAO WASD E SETAS
	var direcao: Vector2 = Input.get_vector(
		"ui_left",
		"ui_right",
		"ui_up",
        "ui_down"
	)

	# MOVIMENTACAO COM ACELERACAO E FRENAGEM
	if direcao != Vector2.ZERO:
		# Acelera gradualmente na direcao escolhida
		velocity = velocity.move_toward(
			 direcao * velocidade,
			aceleracao * delta
		)
	else:
		# Reduz a velocidade gradualmente ao soltar as teclas
		velocity = velocity.move_toward(
			Vector2.ZERO,
			frenagem * delta
		)

	move_and_slide()

	# INICIAR O SALTO
	if Input.is_action_just_pressed("pular") and not pulando:
		pulando = true
		velocidade_vertical = -impulso_salto

	# FISICA DO SALTO
	if pulando:
		velocidade_vertical += gravidade_salto * delta
		altura += velocidade_vertical * delta

		# ATERRISSAGEM
		if altura >= 0.0:
			altura = 0.0
			velocidade_vertical = 0.0
			pulando = false

	# DESLOCAMENTO VISUAL DO ASTRONAUTA
	sprite.position = posicao_original_sprite + Vector2(0.0, altura)
	 # Atualiza a sombra durante o salto
	queue_redraw()

	# ANIMACOES DE MOVIMENTACAO
	if direcao != Vector2.ZERO:
		if abs(direcao.x) > abs(direcao.y):
			ultima_direcao = "direita" if direcao.x > 0 else "esquerda"
		else:
			ultima_direcao = "frente" if direcao.y > 0 else "tras"

		var animacao = "andar_" + ultima_direcao

		if sprite.animation != animacao or not sprite.is_playing():
			sprite.play(animacao)

	else:
		var animacao = "parado_" + ultima_direcao

		if sprite.animation != animacao or not sprite.is_playing():
			sprite.play(animacao)
			
	# SOMBRA DO ASTRONAUTA
func _draw() -> void:
	# A sombra fica mais clara quando o astronauta sobe
	var opacidade: float = clampf(
		0.40 + altura * 0.006,
		0.15,
		0.40
	)

	# Desenha uma sombra oval no chão
	draw_set_transform(
		Vector2(0.0, 22.0),
		0.0,
		Vector2(1.0, 0.4)
	)
	draw_circle(
		Vector2.ZERO,
		12.0,
		Color(0.0, 0.0, 0.0, opacidade)
	)

# Texto sugerido para inscrição — NASA Space Apps 2026

**Nome:** LUNARBIT

**Desafio:** Build a Junior Astronaut Mission Trainer

**Resumo do projeto:**
O LUNARBIT é um protótipo de jogo educativo 2D em pixel art que apresenta a estudantes a rotina e os desafios de administrar uma base lunar fictícia. Desenvolvido com Godot 4, o projeto apresenta exploração da superfície da Lua, três níveis internos dedicados a operações, suporte à vida e habitação, um personagem astronauta, HUD de condições do jogador e sistema de inventário. Sua proposta educativa é tornar visíveis as dependências entre manutenção, energia, água, oxigênio, alimentação e segurança, com inspiração em tecnologias da NASA e da Estação Espacial Internacional.

**Por que se relaciona ao desafio:**
O desafio pede uma experiência interativa na qual jovens compreendam decisões e compromissos necessários para manter um posto lunar ou marciano. Nosso modelo representa visualmente os sistemas e prepara a integração de missões de reparo e gerenciamento de recursos.

**Estado da entrega:** protótipo parcial: cenários e sistemas visuais presentes; transições e missões interativas ainda precisam de ajustes. Sem afirmar funções ainda não testadas como concluídas.

**Tecnologia:** Godot 4 / GDScript / Pixel art.

**Referências:** NASA ISS ECLSS, Quest Airlock, NASA Moon Base concepts e materiais do desafio Space Apps 2026.

**Repositório GitHub:** [ADICIONAR URL DEPOIS DA PUBLICAÇÃO]

**Instruções para conclusão da inscrição:** acesse a página da equipe no site NASA Space Apps 2026 → guia **Project** → adicione descrição e URL do repositório → finalize/submit a inscrição. Publicar no GitHub por si só não conclui a submissão oficial.

# Verificação do pacote de publicação

- Conferido o arquivo `LUNARBIT - DEMO.zip` enviado nesta conversa.
- Foram preservados **148 arquivos** de projeto e documentação na cópia pronta para GitHub.
- Arquivos gerados do cache `.godot/` e configurações locais `.png.import` foram omitidos; o Godot os regenera quando necessário.
- O `project.godot` indica o início em `res://Scenes/main.tscn`. Há também um `main.tscn` na raiz que **não é a cena inicial configurada**.
- As cenas principais dos níveis 1, 2 e 3 e a cena exterior estão presentes, assim como os recursos gráficos citados nessas cenas.
- **Pendências conhecidas:** o retorno entre andares e a saída/posição no mapa exterior ainda precisam de ajustes e testes na máquina da equipe.
- **Cenas auxiliares:** alguns arquivos em `ScenesExtras/` fazem referência a caminhos de recursos experimentais ou cache `.godot/` que não constam como fontes no ZIP recebido. Essas cenas podem não funcionar ao importar o repositório; a cena principal configurada não depende diretamente delas, mas há referências auxiliares.
- Nenhum executável do Godot está instalado neste ambiente; não foi possível afirmar que toda a demo executa corretamente.
- Os gráficos de origem externa e respectivas condições de uso devem ter os créditos/licenças conferidos pela equipe.

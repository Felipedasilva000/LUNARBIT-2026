# Publicação do LUNARBIT no GitHub — passo a passo

## Opção recomendada: GitHub Desktop

1. Descompacte `LUNARBIT_GitHub_PRONTO.zip` em uma pasta, por exemplo, `LUNARBIT`.
2. Instale/abra o [GitHub Desktop](https://desktop.github.com/). Entre na sua conta do GitHub.
3. Selecione **File → Add Local Repository** e escolha a pasta extraída.
4. Se aparecer a pergunta para criar um repositório nessa pasta, escolha **Create a Repository**.
5. Faça um commit inicial com uma mensagem como `Protótipo LUNARBIT — Space Apps 2026`.
6. Clique em **Publish repository**. Use o nome `LUNARBIT-2026` e **desmarque** a opção de manter privado, caso queira um link público para os jurados.
7. Copie o URL completo do repositório e adicione na aba **Project** da equipe em [NASA Space Apps 2026](https://www.spaceappschallenge.org/2026/).

## Se o repositório já existe

Clone-o usando GitHub Desktop, copie o **conteúdo** do ZIP extraído para dentro da pasta clonada, faça o commit e o push. Não copie a pasta `.git/` de outro repositório nem carregue o ZIP sem descompactar.

## Importante

- Publicar no GitHub **não substitui** a submissão na plataforma da NASA.
- O prazo oficial de 2026 é **15 de novembro, 23h59 no horário local aplicável à equipe**, conforme as regras do evento; confira a página de seu time.
- Há bugs de transição conhecidos, documentados no README; não declare essas funções como finalizadas.
- Se os gráficos tiverem origem externa, confirme direitos de uso.

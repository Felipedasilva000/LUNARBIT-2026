# Pitch LUNARBIT — roteiro de 5 minutos

**Formato recomendado:** apresentar o jogo aberto e mostrar movimentação, os três andares e o HUD; não prometer que uma missão já está programada se ela não estiver funcional.

## 0:00–0:40 — O problema

“Como ensinar a estudantes que viver na Lua não depende apenas de chegar lá? É preciso manter energia, água, oxigênio, equipamentos e a saúde da tripulação funcionando juntos. Esses sistemas são complexos, mas podem se tornar acessíveis por meio de uma experiência interativa.”

## 0:40–1:20 — A solução

“Criamos o LUNARBIT, um protótipo educativo em pixel art, desenvolvido no Godot, no qual o jogador controla um astronauta e explora uma base lunar fictícia. Nosso objetivo é transformar operações técnicas em decisões que o estudante consegue compreender.”

## 1:20–2:20 — Demonstração do jogo

**Ação na tela:** mostrar o cenário externo, o Microastro e a entrada no habitat. Se a transição entre cenas ainda falhar, abrir cada andar diretamente no Godot, sem afirmar que a passagem funciona.

“Dividimos a base em três níveis: no primeiro, manutenção e operações; no segundo, suporte à vida; e no terceiro, habitação e comando. Cada ambiente foi planejado com equipamentos inspirados em tecnologias espaciais reais.”

## 2:20–3:15 — Sistemas e educação

**Ação na tela:** destacar o HUD de sede, fome e sanidade e a interface de inventário.

“O jogador acompanha condições de sobrevivência e organiza ferramentas e suprimentos. Queremos que compreenda relações entre recursos: energia alimenta os sistemas ambientais; água participa do suporte à vida e do cultivo; e manutenção previne falhas de operação. As taxas e indicadores do jogo são valores didáticos, não valores oficiais da NASA.”

## 3:15–4:05 — Referência científica e diferenciais

“Nos inspiramos nos sistemas ECLSS da ISS, em tecnologias de eclusas, exercícios, cultivo experimental, manutenção e exploração lunar divulgadas pela NASA. A base apresentada é um conceito de jogo — não estamos dizendo que uma instalação humana permanente já opera na Lua. Nossa proposta combina acessibilidade visual, exploração e pensamento sistêmico.”

## 4:05–4:45 — Estado atual e próximos passos

“Este é um protótipo desenvolvido para o hackathon. Já construímos o mapa externo, três ambientes internos, sprites do personagem, interface de status e inventário. A próxima etapa é concluir a conexão entre as cenas e transformar equipamentos em missões de diagnóstico, reparo e tomada de decisão.”

## 4:45–5:00 — Encerramento

“Com o LUNARBIT, queremos aproximar estudantes dos desafios reais da exploração espacial: entender que cada decisão em uma base lunar tem consequências. Esse é o começo de uma experiência de treinamento acessível e divertida.”

**Checklist da apresentação:** testar F5; confirmar cenas que abrem; evitar demonstrar bugs; deixar README visível; apresentar a situação real do protótipo com transparência; inserir o link do GitHub na plataforma oficial.

extends Node2D

# Arraste esta cena para cima de uma bancada / armario do seu mapa.
@export var nome_local: String = "Bancada de manutencao"
@export var item_aceito: String = "chave_fenda"
@export var mostrar_marcador: bool = true

var item_guardado: String = ""
var _sprite: Sprite2D

func _ready() -> void:
    add_to_group("lunarbit_ponto_item")
    _sprite = Sprite2D.new()
    _sprite.name = "ItemGuardado"
    _sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    _sprite.scale = Vector2(0.65, 0.65)
    add_child(_sprite)
    _atualizar_icone()

func guardar_item(id: String) -> bool:
    if item_guardado != "":
        return false
    if item_aceito != "" and item_aceito != id:
        return false
    item_guardado = id
    _atualizar_icone()
    return true

func retirar_item() -> String:
    var id: String = item_guardado
    item_guardado = ""
    _atualizar_icone()
    return id

func _atualizar_icone() -> void:
    if _sprite == null:
        return
    if item_guardado == "":
        _sprite.texture = null
    else:
        _sprite.texture = load("res://LUNARBIT_Inventario/assets/itens/%s.png" % item_guardado) as Texture2D
    queue_redraw()

func _draw() -> void:
    if not mostrar_marcador:
        return
    draw_rect(Rect2(-13, -12, 26, 24), Color(0.09, 0.17, 0.26, 0.45))
    draw_rect(Rect2(-13, -12, 26, 24), Color(0.93, 0.62, 0.22, 0.85), false, 1.0)

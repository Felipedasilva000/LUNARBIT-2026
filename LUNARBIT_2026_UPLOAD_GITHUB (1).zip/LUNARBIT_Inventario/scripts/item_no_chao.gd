extends Node2D

@export var id_item: String = "chave_fenda"

var _sprite: Sprite2D

func _ready() -> void:
    add_to_group("lunarbit_item_no_chao")
    _sprite = Sprite2D.new()
    _sprite.name = "IconeItem"
    _sprite.texture = load("res://LUNARBIT_Inventario/assets/itens/%s.png" % id_item) as Texture2D
    _sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
    add_child(_sprite)
    queue_redraw()

func _draw() -> void:
    draw_circle(Vector2(0, 3), 11.0, Color(0.02, 0.06, 0.10, 0.55))
    draw_arc(Vector2.ZERO, 13.0, 0.0, TAU, 24, Color(0.1, 0.78, 0.94, 0.7), 1.0)

extends Node2D

# LUNARBIT - inventario persistente, independente do jogador.
# Instanciado UMA vez no Autoload SistemaGlobal, acompanha trocas de cena.
# Controles: 1-5, F pegar, G soltar, R guardar/retirar, U usar.

signal inventario_alterado(itens: Array)
signal item_coletado(id_item: String)
signal item_solto(id_item: String)
signal item_guardado(id_item: String, local: String)
signal item_retirado(id_item: String, local: String)

@export_group("Jogador")
@export var grupo_jogador: StringName = &"jogador"
@export_range(16.0, 200.0, 1.0) var raio_interacao: float = 52.0

@export_group("Interface")
@export_range(0.5, 2.0, 0.05) var escala_barra: float = 1.0
@export var escala_automatica: bool = true
@export_range(0.0, 60.0, 1.0) var margem_inferior: float = 6.0

@export_group("Teste")
@export var criar_itens_para_teste: bool = true
@export var criar_bancada_teste: bool = true
@export var itens_iniciais: Array[String] = []

const N_SLOTS: int = 5
const LARGURA: float = 218.0
const ALTURA: float = 46.0
const X_PRIMEIRO: float = 13.0
const PASSO: float = 40.0
const Y_SLOT: float = 9.0
const QUADRO: Texture2D = preload("res://LUNARBIT_Inventario/assets/hotbar_frame.png")
const DESTAQUE: Texture2D = preload("res://LUNARBIT_Inventario/assets/slot_selecionado.png")
const CENA_CHAO: PackedScene = preload("res://LUNARBIT_Inventario/scenes/item_no_chao.tscn")
const CENA_PONTO: PackedScene = preload("res://LUNARBIT_Inventario/scenes/ponto_item.tscn")
const ICONES := {
	"chave_fenda": preload("res://LUNARBIT_Inventario/assets/itens/chave_fenda.png"),
	"filtro": preload("res://LUNARBIT_Inventario/assets/itens/filtro.png"),
	"agua": preload("res://LUNARBIT_Inventario/assets/itens/agua.png"),
	"amostra": preload("res://LUNARBIT_Inventario/assets/itens/amostra.png"),
	"modulo_eletrico": preload("res://LUNARBIT_Inventario/assets/itens/modulo_eletrico.png"),
}
const NOMES := {
	"chave_fenda": "Chave de fenda",
	"filtro": "Filtro",
	"agua": "Bolsa de agua",
	"amostra": "Amostra lunar",
	"modulo_eletrico": "Modulo eletrico",
}

var slots: Array[String] = ["", "", "", "", ""]
var slot_ativo: int = 0
var _jogador: Node2D
var _camada: CanvasLayer
var _painel: Control
var _icone_slots: Array[TextureRect] = []
var _destaques: Array[TextureRect] = []
var _dica: Label

# Estado em memoria: persiste durante mudancas de andar na mesma partida.
var _soltos_por_cena: Dictionary = {}  # caminho da cena -> [{uid, id, pos}]
var _pontos_por_cena: Dictionary = {}  # caminho da cena e caminho do ponto -> item
var _proximo_uid: int = 1
var _instancia_cena_preparada: int = 0
var _cenas_demo_criadas: Dictionary = {}
var _itens_fixos_coletados: Dictionary = {}
var _aviso: String = ""
var _segundos_aviso: float = 0.0

func _ready() -> void:
	_criar_interface()
	_atualizar_visual()
	get_viewport().size_changed.connect(_reposicionar_barra)
	get_tree().scene_changed.connect(_ao_trocar_cena)
	for id in itens_iniciais:
		adicionar_item(id)
	# Objetos de demonstracao sao gerados na cena ativa, e nao no Autoload.
	# A preparacao da primeira cena tambem e feita em _process.

func _cena_atual() -> Node:
	return get_tree().current_scene

func _jogador_da_cena() -> Node2D:
	var cena: Node = _cena_atual()
	if cena == null:
		return null

	if is_instance_valid(_jogador) and (cena == _jogador or cena.is_ancestor_of(_jogador)):
		return _jogador
	_jogador = null

	# Metodo recomendado: adicionar o grupo "jogador" ao personagem em cada cena.
	for no in get_tree().get_nodes_in_group(grupo_jogador):
		if no is Node2D and (cena == no or cena.is_ancestor_of(no)):
			_jogador = no as Node2D
			return _jogador

	# Compatibilidade com projeto antigo que usa PlayerMicroastro.
	for nome in ["PlayerMicroastro", "Astronauta", "Player", "player"]:
		var candidatos: Array[Node] = cena.find_children(nome, "Node2D", true, false)
		if not candidatos.is_empty():
			_jogador = candidatos[0] as Node2D
			return _jogador

	# Ultimo recurso: somente se a cena possuir UM CharacterBody2D.
	var corpos: Array[Node] = cena.find_children("*", "CharacterBody2D", true, false)
	if corpos.size() == 1:
		_jogador = corpos[0] as Node2D
		return _jogador
	return null

func _chave_cena(cena: Node = null) -> String:
	if cena == null:
		cena = _cena_atual()
	if cena == null:
		return ""
	return cena.scene_file_path

func _ao_trocar_cena(_nova_cena: Node) -> void:
	_jogador = null
	_instancia_cena_preparada = 0

func _preparar_cena(cena: Node) -> void:
	if not is_instance_valid(cena) or cena != _cena_atual():
		return
	if _jogador_da_cena() == null:
		_instancia_cena_preparada = 0
		return

	var chave: String = _chave_cena(cena)
	if chave == "":
		return

	# Itens fixos posicionados manualmente no editor nao devem reaparecer
	# depois de coletados quando o jogador retorna a uma cena.
	for item in get_tree().get_nodes_in_group("lunarbit_item_no_chao"):
		if item is Node2D and cena.is_ancestor_of(item):
			if _itens_fixos_coletados.has(_chave_item_fixo(item)):
				item.remove_from_group("lunarbit_item_no_chao")
				item.queue_free()

	# Restaura ferramentas largadas no chao durante a partida.
	for registro in _soltos_por_cena.get(chave, []):
		var pos: Vector2 = registro["pos"]
		_instanciar_item_no_cenario(str(registro["id"]), pos, int(registro["uid"]))

	# Cria amostras de itens e uma bancada interativa na PRIMEIRA visita
	# a cada andar. Nunca renasce um item ja coletado.
	if criar_itens_para_teste and not _cenas_demo_criadas.has(chave):
		_cenas_demo_criadas[chave] = true
		_criar_demo_na_cena(cena)
	elif criar_itens_para_teste and criar_bancada_teste:
		_criar_bancada_demo(cena)

	# Recupera o conteudo dos pontos de armazenamento (manuais ou demo).
	for ponto in get_tree().get_nodes_in_group("lunarbit_ponto_item"):
		if not (ponto is Node2D) or not cena.is_ancestor_of(ponto):
			continue
		var chave_ponto: String = _chave_ponto(ponto)
		if _pontos_por_cena.has(chave_ponto):
			ponto.set("item_guardado", _pontos_por_cena[chave_ponto])
			ponto.call("_atualizar_icone")

func _criar_demo_na_cena(cena: Node) -> void:
	var jogador: Node2D = _jogador_da_cena()
	if jogador == null:
		return
	# Criar uma amostra perto do jogador em CADA cena, inclusive interiores.
	criar_item_no_chao("chave_fenda", jogador.global_position + Vector2(32, 0))
	criar_item_no_chao("filtro", jogador.global_position + Vector2(-32, 0))
	if criar_bancada_teste:
		_criar_bancada_demo(cena)

func _criar_bancada_demo(cena: Node) -> void:
	if cena.get_node_or_null("BancadaDemoInventario") != null:
		return
	var jogador: Node2D = _jogador_da_cena()
	if jogador == null:
		return
	var ponto: Node2D = CENA_PONTO.instantiate() as Node2D
	ponto.name = "BancadaDemoInventario"
	ponto.set("nome_local", "Bancada de teste")
	ponto.set("item_aceito", "")
	ponto.set("mostrar_marcador", true)
	cena.add_child(ponto)
	ponto.global_position = jogador.global_position + Vector2(0, 36)

func _chave_item_fixo(item: Node2D) -> String:
	var cena: Node = _cena_atual()
	if cena == null or not cena.is_ancestor_of(item):
		return ""
	return "%s::%s" % [_chave_cena(cena), str(cena.get_path_to(item))]

func _chave_ponto(ponto: Node2D) -> String:
	var cena: Node = _cena_atual()
	if cena == null or not cena.is_ancestor_of(ponto):
		return ""
	return "%s::%s" % [_chave_cena(cena), str(cena.get_path_to(ponto))]

func _registrar_estado_ponto(ponto: Node2D) -> void:
	var chave: String = _chave_ponto(ponto)
	if chave != "":
		_pontos_por_cena[chave] = str(ponto.get("item_guardado"))

func _criar_interface() -> void:
	_camada = CanvasLayer.new()
	_camada.name = "CamadaInventario"
	_camada.layer = 15
	add_child(_camada)

	_painel = Control.new()
	_painel.name = "Barra5Itens"
	_painel.size = Vector2(LARGURA, ALTURA)
	_painel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_camada.add_child(_painel)

	var moldura := TextureRect.new()
	moldura.name = "FundoMetalico"
	moldura.texture = QUADRO
	moldura.size = Vector2(LARGURA, ALTURA)
	moldura.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	moldura.stretch_mode = TextureRect.STRETCH_SCALE
	moldura.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	moldura.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_painel.add_child(moldura)

	for i in range(N_SLOTS):
		var x: float = X_PRIMEIRO + float(i) * PASSO
		var destaque := TextureRect.new()
		destaque.name = "Selecao%d" % (i + 1)
		destaque.texture = DESTAQUE
		destaque.position = Vector2(x - 1, Y_SLOT - 1)
		destaque.size = Vector2(34, 32)
		destaque.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		destaque.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		destaque.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_painel.add_child(destaque)
		_destaques.append(destaque)

		var icone := TextureRect.new()
		icone.name = "Item%d" % (i + 1)
		icone.position = Vector2(x + 4, Y_SLOT + 3)
		icone.size = Vector2(24, 24)
		icone.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		icone.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		icone.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		icone.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_painel.add_child(icone)
		_icone_slots.append(icone)

		var numero := Label.new()
		numero.text = str(i + 1)
		numero.position = Vector2(x + 24, Y_SLOT + 19)
		numero.add_theme_font_size_override("font_size", 8)
		numero.add_theme_color_override("font_color", Color(0.77, 0.85, 0.92))
		numero.mouse_filter = Control.MOUSE_FILTER_IGNORE
		_painel.add_child(numero)

		var botao := Button.new()
		botao.name = "Selecionar%d" % (i + 1)
		botao.flat = true
		botao.focus_mode = Control.FOCUS_NONE
		botao.position = Vector2(x, Y_SLOT)
		botao.size = Vector2(32, 30)
		botao.mouse_filter = Control.MOUSE_FILTER_STOP
		botao.pressed.connect(_ao_clicar_slot.bind(i))
		_painel.add_child(botao)

	_dica = Label.new()
	_dica.name = "DicaInventario"
	_dica.add_theme_font_size_override("font_size", 10)
	_dica.add_theme_color_override("font_color", Color(0.72, 0.92, 0.98))
	_dica.add_theme_color_override("font_shadow_color", Color(0.02, 0.04, 0.08, 0.9))
	_dica.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_dica.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_dica.size = Vector2(300, 16)
	_camada.add_child(_dica)

	_reposicionar_barra()

func _reposicionar_barra() -> void:
	if _painel == null:
		return
	var tela: Vector2 = get_viewport().get_visible_rect().size
	var escala: float = escala_barra
	if escala_automatica:
		escala *= clampf(tela.x / 320.0, 1.0, 1.6)
	_painel.scale = Vector2.ONE * escala
	_painel.position = Vector2((tela.x - LARGURA * escala) * 0.5,
		tela.y - ALTURA * escala - margem_inferior)
	if _dica != null:
		_dica.position = Vector2((tela.x - 300.0) * 0.5,
			_painel.position.y - 18.0)

func _ao_clicar_slot(indice: int) -> void:
	selecionar_slot(indice)

func selecionar_slot(indice: int) -> void:
	slot_ativo = clampi(indice, 0, N_SLOTS - 1)
	_atualizar_visual()

func _atualizar_visual() -> void:
	for i in range(N_SLOTS):
		_destaques[i].visible = i == slot_ativo
		var id: String = slots[i]
		_icone_slots[i].texture = ICONES.get(id, null)
	inventario_alterado.emit(slots.duplicate())

func _process(delta: float) -> void:
	var cena: Node = _cena_atual()
	if cena != null and _instancia_cena_preparada != cena.get_instance_id():
		if _jogador_da_cena() != null:
			_instancia_cena_preparada = cena.get_instance_id()
			call_deferred("_preparar_cena", cena)

	if _dica == null:
		return
	if _segundos_aviso > 0.0:
		_segundos_aviso -= delta
		_dica.text = _aviso
		return
	if _jogador_da_cena() == null:
		_dica.text = "Aguardando astronauta..."
		return

	var item_chao := _proximo_do_grupo("lunarbit_item_no_chao")
	var ponto := _proximo_do_grupo("lunarbit_ponto_item")
	var texto: String = "1-5 selecionar | F pegar | G soltar | U usar"
	if item_chao != null:
		texto = "F pegar: %s" % NOMES.get(str(item_chao.get("id_item")), "item")
	elif ponto != null:
		texto = "R guardar / retirar: %s" % str(ponto.get("nome_local"))
	elif slots[slot_ativo] != "":
		texto = "%s | G soltar | U usar" % NOMES.get(slots[slot_ativo], "Item")
	_dica.text = texto

func _mostrar_aviso(texto: String) -> void:
	_aviso = texto
	_segundos_aviso = 2.5
	if _dica != null:
		_dica.text = texto

func _unhandled_input(event: InputEvent) -> void:
	if not (event is InputEventKey):
		return
	var tecla: InputEventKey = event as InputEventKey
	if not tecla.pressed or tecla.echo:
		return
	match tecla.keycode:
		KEY_1, KEY_2, KEY_3, KEY_4, KEY_5:
			selecionar_slot(int(tecla.keycode) - int(KEY_1))
			get_viewport().set_input_as_handled()
		KEY_F:
			_pegar_item_proximo()
			get_viewport().set_input_as_handled()
		KEY_G:
			soltar_item_selecionado()
			get_viewport().set_input_as_handled()
		KEY_R:
			_interagir_com_ponto()
			get_viewport().set_input_as_handled()
		KEY_U:
			usar_item_selecionado()
			get_viewport().set_input_as_handled()

func _proximo_do_grupo(grupo: String) -> Node2D:
	var jogador: Node2D = _jogador_da_cena()
	var cena: Node = _cena_atual()
	if jogador == null or cena == null:
		return null
	var melhor: Node2D = null
	var distancia_melhor: float = raio_interacao
	for n in get_tree().get_nodes_in_group(grupo):
		if not is_instance_valid(n) or not (n is Node2D):
			continue
		if not cena.is_ancestor_of(n):
			continue
		var candidato: Node2D = n as Node2D
		var distancia: float = jogador.global_position.distance_to(candidato.global_position)
		if distancia <= distancia_melhor:
			distancia_melhor = distancia
			melhor = candidato
	return melhor

func _pegar_item_proximo() -> void:
	var proximo := _proximo_do_grupo("lunarbit_item_no_chao")
	if proximo == null:
		_mostrar_aviso("Nenhum item proximo para pegar")
		return
	var id: String = str(proximo.get("id_item"))
	if adicionar_item(id):
		if proximo.has_meta("uid_item_solto"):
			_desregistrar_item_solto(proximo)
		else:
			var chave_fixa: String = _chave_item_fixo(proximo)
			if chave_fixa != "":
				_itens_fixos_coletados[chave_fixa] = true
		proximo.remove_from_group("lunarbit_item_no_chao")
		proximo.queue_free()
		item_coletado.emit(id)
		print("LUNARBIT: coletou ", NOMES.get(id, id))
		_mostrar_aviso("Coletado: %s" % NOMES.get(id, id))

func adicionar_item(id: String) -> bool:
	if not ICONES.has(id):
		push_warning("Inventario: item desconhecido: " + id)
		return false
	for i in range(N_SLOTS):
		if slots[i] == "":
			slots[i] = id
			_atualizar_visual()
			return true
	print("LUNARBIT: inventario cheio (5 slots)")
	_mostrar_aviso("Inventario cheio: 5 itens")
	return false

func remover_item(id: String) -> bool:
	for i in range(N_SLOTS):
		if slots[i] == id:
			slots[i] = ""
			_atualizar_visual()
			return true
	return false

func tem_item(id: String) -> bool:
	return slots.has(id)

func item_selecionado() -> String:
	return slots[slot_ativo]

func soltar_item_selecionado() -> void:
	var jogador: Node2D = _jogador_da_cena()
	if jogador == null:
		_mostrar_aviso("Astronauta nao encontrado")
		return
	var id: String = slots[slot_ativo]
	if id == "":
		_mostrar_aviso("Selecione um item para soltar")
		return
	var pos: Vector2 = jogador.global_position + Vector2(23, 18)
	if criar_item_no_chao(id, pos) == null:
		return
	slots[slot_ativo] = ""
	_atualizar_visual()
	item_solto.emit(id)
	_mostrar_aviso("Item colocado no chao: %s" % NOMES.get(id, id))

func criar_item_no_chao(id: String, posicao_global: Vector2) -> Node2D:
	if not ICONES.has(id):
		return null
	var uid: int = _proximo_uid
	_proximo_uid += 1
	var novo: Node2D = _instanciar_item_no_cenario(id, posicao_global, uid)
	if novo == null:
		return null
	var chave: String = _chave_cena()
	if chave != "":
		var registros: Array = _soltos_por_cena.get(chave, [])
		registros.append({"uid": uid, "id": id, "pos": posicao_global})
		_soltos_por_cena[chave] = registros
	return novo

func _instanciar_item_no_cenario(id: String, posicao_global: Vector2, uid: int) -> Node2D:
	var cena: Node = _cena_atual()
	if cena == null:
		return null
	var no: Node2D = CENA_CHAO.instantiate() as Node2D
	no.set("id_item", id)
	no.set_meta("uid_item_solto", uid)
	cena.add_child(no)  # Nunca colocar o objeto no Autoload.
	no.global_position = posicao_global
	return no

func _desregistrar_item_solto(no: Node2D) -> void:
	if not no.has_meta("uid_item_solto"):
		return
	var uid: int = int(no.get_meta("uid_item_solto"))
	var chave: String = _chave_cena()
	var registros: Array = _soltos_por_cena.get(chave, [])
	for i in range(registros.size() - 1, -1, -1):
		if int(registros[i]["uid"]) == uid:
			registros.remove_at(i)
	_soltos_por_cena[chave] = registros

func _interagir_com_ponto() -> void:
	var ponto := _proximo_do_grupo("lunarbit_ponto_item")
	if ponto == null:
		_mostrar_aviso("Nenhuma bancada proxima")
		return
	var guardado: String = str(ponto.get("item_guardado"))
	var local: String = str(ponto.get("nome_local"))
	if guardado != "":
		if adicionar_item(guardado):
			ponto.call("retirar_item")
			_registrar_estado_ponto(ponto)
			item_retirado.emit(guardado, local)
			print("LUNARBIT: retirou item da(o) ", local)
			_mostrar_aviso("Retirado: %s" % NOMES.get(guardado, guardado))
		return
	var atual: String = item_selecionado()
	if atual == "":
		_mostrar_aviso("Selecione um item para guardar")
		return
	if bool(ponto.call("guardar_item", atual)):
		_registrar_estado_ponto(ponto)
		slots[slot_ativo] = ""
		_atualizar_visual()
		item_guardado.emit(atual, local)
		print("LUNARBIT: guardou ", NOMES.get(atual, atual), " em ", local)
		_mostrar_aviso("Guardado: %s" % NOMES.get(atual, atual))
	else:
		print("LUNARBIT: local nao aceita esse item ou esta ocupado")
		_mostrar_aviso("Esse local nao aceita o item")

func usar_item_selecionado() -> void:
	var id: String = item_selecionado()
	if id == "":
		_mostrar_aviso("Selecione um item para usar")
		return

	# Demonstra interacao real com o HUD: agua recupera sede.
	if id == "agua":
		var hud: Node = get_node_or_null("/root/SistemaGlobal/HUD_Astronautico")
		if hud == null or not hud.has_method("alterar_sede"):
			_mostrar_aviso("HUD de sede nao encontrado")
			return
		hud.call("alterar_sede", 25.0)
		slots[slot_ativo] = ""
		_atualizar_visual()
		_mostrar_aviso("Agua consumida: sede +25")
		return

	_mostrar_aviso("%s: usar em um equipamento da missao" % NOMES.get(id, id))

# API de missao: uma estufa pode verificar inv.tem_item("chave_fenda")
# e entao inv.remover_item("filtro") quando o reparo consumir um filtro.
